# Repo da Aula de Backend da Satc

## Informações:
- Respostas das ativiades salvos nas pastas `/atividade-*`
- Repositorio do trabalho [Intermediário](https://github.com/thiagolarangeiras/satc-backend-intermediario)

- pdf de explições das aulas [/explicacao](./explicacao/)
- pdf de exemplos das aulas [/exemplos](./exemplos)
## Outros Repositorios
[Professor Ramon Venson](https://gitlab.com/professor-rvenson/backend-satc-2024a)
