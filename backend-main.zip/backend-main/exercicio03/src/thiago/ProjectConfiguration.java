package thiago;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("thiago")
public class ProjectConfiguration {
}
