package thiago;

public interface Indicavel {
    String getValores();
    Boolean getElegivel();
    Short getNumeroDeIndicacoes();

    void setElegivel(Boolean elegivel);
    void setNumeroDeIndicacoes(Short numeroDeIndicacoes);
}
