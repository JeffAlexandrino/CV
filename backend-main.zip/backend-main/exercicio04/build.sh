#!/bin/sh

#mvn spring-boot:run
rm -rf ./target/
./mvnw spring-boot:run
