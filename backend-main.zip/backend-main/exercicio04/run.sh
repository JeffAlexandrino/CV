#!/bin/sh

#mvn spring-boot:run
./mvnw spring-boot:run
